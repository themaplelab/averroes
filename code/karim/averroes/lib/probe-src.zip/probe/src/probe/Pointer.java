package probe;
/** A represenatation of a pointer variable. */
public interface Pointer {}
