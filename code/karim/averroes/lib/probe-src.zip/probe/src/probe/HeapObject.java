package probe;
/** A represenatation of an object allocated on the heap. */
public interface HeapObject {}
